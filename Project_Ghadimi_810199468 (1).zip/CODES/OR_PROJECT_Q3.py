import pandas as pd
import networkx as nx

def run_program():
    # Load the CSV file
    df = pd.read_csv('data (1).csv')

    # Create a directed graph
    graph = nx.DiGraph()

    # Add nodes to the graph
    for _, row in df.iterrows():
        graph.add_node(row['name'], longitude=row['longitude'], latitude=row['latitude'])

    # Add edges to the graph
    for _, row in df.iterrows():
        neighbors_indices = row['neighbors_indice'].split(',')
        neighbors_weights = row['neighbors_weihgt'].split(',')
        for neighbor_index, neighbor_weight in zip(neighbors_indices, neighbors_weights):
            graph.add_edge(row['name'], df.loc[int(neighbor_index), 'name'], weight=float(neighbor_weight))

    # Prompt the user to enter the start and end point names or indices separated by a space
    start_input, end_input = input("Enter the start and end point names or indices (separated by a space): ").split()

    # Check if the inputs are indices
    if start_input.isdigit() and end_input.isdigit():
        start = df.loc[int(start_input), 'name']
        end = df.loc[int(end_input), 'name']
    else:
        start = start_input
        end = end_input

    # Filter the DataFrame based on the start and end names
    filtered_df = df[df['name'].isin([start, end])]

    # Reset the index of the filtered DataFrame
    filtered_df = filtered_df.reset_index(drop=True)

    # Print the information for the start and end names
    print(filtered_df.to_string(index=False))

    # Calculate the shortest path
    try:
        shortest_path = nx.shortest_path(graph, start, end, weight='weight')
        shortest_distance = nx.shortest_path_length(graph, start, end, weight='weight')
        print(f"Shortest path: {' -> '.join(shortest_path)}")
        print(f"Shortest distance: {shortest_distance:.2f}")
    except nx.NetworkXNoPath:
        print("There is no path between the start and end points.")

    # Ask the user if they want to run the program again
    run_again = input("Do you want to run the program again? (yes/no): ")
    if run_again.lower() == 'yes':
        run_program()
    else :
        print("END!!!")

run_program()
